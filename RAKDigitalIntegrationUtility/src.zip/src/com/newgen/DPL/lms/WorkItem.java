package com.newgen.DPL.lms;

public class WorkItem {
	public String processInstanceId;
	public String workItemId;
	public String WI_NAME;
	public String phoneNumber;
	public String branchCode;
	public String emailId;
	public String ACCOUNT_TYPE;
}
