package com.newgen.DCC.DECTECHIntegration;

public class Snippet {
	public static void main(String[] args) {
	}
}

